#include <cstdlib>
#include <iostream>

#include "valor.h"

using namespace std;


int main(int argc, char** argv) {

    valor obj;
    obj.lerDados();
    
    return 0;
}

