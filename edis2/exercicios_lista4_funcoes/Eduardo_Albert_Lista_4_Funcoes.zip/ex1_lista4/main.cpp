#include <cstdlib>

#include "numero.h"

using namespace std;


int main(int argc, char** argv) {

    numero obj;
    obj.lerDados();
    
    return 0;
}