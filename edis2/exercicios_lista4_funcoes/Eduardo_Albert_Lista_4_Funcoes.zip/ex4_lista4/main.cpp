#include <cstdlib>
#include "equacaoSegundoGrau.h"

using namespace std;


int main(int argc, char** argv) {
    
    equacaoSegundoGrau obj;
    obj.lerCoeficientes();
    
    return 0;
}

