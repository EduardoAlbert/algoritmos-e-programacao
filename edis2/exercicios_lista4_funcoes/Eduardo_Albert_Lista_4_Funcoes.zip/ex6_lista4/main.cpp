#include <cstdlib>

#include "verificaTriangulo.h"

using namespace std;


int main(int argc, char** argv) {

    verificaTriangulo obj;
    obj.lerDados();
    
    return 0;
}

