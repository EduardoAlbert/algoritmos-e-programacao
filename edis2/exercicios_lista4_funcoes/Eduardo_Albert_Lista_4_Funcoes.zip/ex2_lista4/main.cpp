#include <cstdlib>
#include <iostream>
#include "cAluno.h"

using namespace std;


int main(int argc, char** argv) {

    cAluno obj;
    obj.lerDados();
    
    return 0;
}

