#include <cstdlib>

#include "cConta.h"

using namespace std;


int main(int argc, char** argv) {

    cConta obj;
    obj.criarContas();
    
    return 0;
}

