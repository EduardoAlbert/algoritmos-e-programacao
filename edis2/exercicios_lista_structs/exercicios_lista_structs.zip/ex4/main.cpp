#include <cstdlib>

#include "cProduto.h"

using namespace std;


int main(int argc, char** argv) {

    cProduto obj;
    obj.cadastrarProdutos();
    obj.consultarPrecoPorCodigo();
    
    return 0;
}

