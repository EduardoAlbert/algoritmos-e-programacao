#include <cstdlib>

#include "cPessoa.h"


int main(int argc, char** argv) {
    
    cPessoa obj;
    obj.lerDados();
    
    return 0;
}

